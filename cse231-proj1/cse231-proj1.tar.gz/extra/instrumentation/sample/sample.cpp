#include <stdio.h>

int count;

void sample() {
    printf("Count = %d\n", count);
    count++;
}
